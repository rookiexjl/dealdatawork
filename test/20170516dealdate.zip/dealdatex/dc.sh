#!/bin/bash
rm -f dc/first_set/*
rm -f dc/dir1/*
rm -f dc/dir3c/*
rm -f dc/dirresult/*
rm -f dc/nresult/*
echo "rm -f success"
python dc/dealDate.py
echo "success dealDate.py"
echo "success"

